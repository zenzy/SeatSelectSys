import {AfterViewInit, Component, ElementRef, Input, ViewChild} from '@angular/core';
import {GetLastDateProvider} from "../../providers/get-last-date/get-last-date";
import {SendMessageProvider} from "../../providers/send-message/send-message";
declare const echarts;
/**
 * Generated class for the StatisticWeeklyComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'statistic-weekly',
  templateUrl: 'statistic-weekly.html'
})
export class StatisticWeeklyComponent implements AfterViewInit{

  @Input('userId')
  public userId:string;

  @ViewChild('weeklyCharts')
  private weeklyChart:ElementRef;
  private weekChart:any;
  private lastMonday:string;
  private lastSunday:string;
  private lastMondayTime:any;
  private lastSundayTime:any;
  public echartData:number[] = [0,0,0,0,0,0,0];
  private summaryInfo = {
    totalStudyTime:0,
    avgStudyTime:0,
    maxStudyTime:0,
    minStudyTime:0,
  };
  constructor(public sendMsg:SendMessageProvider,public getdate:GetLastDateProvider) {
    let today = new Date();
    this.lastMonday = this.getdate.getLastMondy(today);
    this.lastSunday = this.getdate.getLastSunday(today);
    this.lastMondayTime = new Date(this.lastMonday+' 00:00:00').getTime();
    this.lastSundayTime = new Date(this.lastSunday+' 23:00:00').getTime();
  }

  ngAfterViewInit(): void {
    console.log(this.userId);
    this.sendMsg.sendMessageReturn('WeekStatisticServlet',{userId:this.userId,appointTimeStart:this.lastMondayTime,appointTimeEnd:this.lastSundayTime})
      .map(res => res.json())
      .subscribe(data => {
        for(var i=0;i<7;i++){
          for(let key in data[i]){
            let day = new Date(key).getDay();
            switch (day){
              //除以3600000是将毫秒转换成小时
              case 1:this.echartData[0] = parseFloat((data[i][key]/3600000).toFixed(4));break;
              case 2:this.echartData[1] = parseFloat((data[i][key]/3600000).toFixed(4));break;
              case 3:this.echartData[2] = parseFloat((data[i][key]/3600000).toFixed(4));break;
              case 4:this.echartData[3] = parseFloat((data[i][key]/3600000).toFixed(4));break;
              case 5:this.echartData[4] = parseFloat((data[i][key]/3600000).toFixed(4));break;
              case 6:this.echartData[5] = parseFloat((data[i][key]/3600000).toFixed(4));break;
              case 0:this.echartData[6] = parseFloat((data[i][key]/3600000).toFixed(4));break;
            }
          }
          this.summaryInfo.maxStudyTime = Math.max.apply({},this.echartData);
          this.summaryInfo.minStudyTime = Math.min.apply({},this.echartData);
          this.summaryInfo.totalStudyTime = parseFloat((eval(this.echartData.join("+"))).toFixed(4));
          this.summaryInfo.avgStudyTime = parseFloat((eval(this.echartData.join("+"))/7).toFixed(4));

        }
        this.echartsView(this.echartData);
      });
  }

  echartsView(data){
    this.weekChart = echarts.init(this.weeklyChart.nativeElement);
    let option =  {
      title : {
        text: '上周选座记录统计',
      },
      tooltip : {
        trigger: 'axis'
      },
      toolbox: {
        show : true,
        feature : {
          mark : {show: true},
          dataView : {show: true, readOnly: false},
          magicType : {show: true, type: ['line', 'bar']},
          restore : {show: true},
          saveAsImage : {show: true}
        }
      },
      calculable : true,
      xAxis : [
        {
          type : 'category',
          data : ['星期一','星期二','星期三','星期四','星期五','星期六','星期日']
        }
      ],
      yAxis : [
        {
          type : 'value'
        }
      ],
      series : [
        {
          name:'学习时间',
          type:'bar',
          data:data,
          markPoint : {
            data : [
              {type : 'max', name: '最大值'},
              {type : 'min', name: '最小值'}
            ]
          },
          markLine : {
            data : [
              {type : 'average', name: '平均值'}
            ]
          }
        },

      ]
    };
    this.weekChart.setOption(option);
  }
}
