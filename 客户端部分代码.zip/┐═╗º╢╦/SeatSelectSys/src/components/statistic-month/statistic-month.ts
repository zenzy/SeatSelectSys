import {Component, ElementRef, Input,ViewChild} from '@angular/core';
import {SendMessageProvider} from "../../providers/send-message/send-message";
declare const echarts;

/**
 * Generated class for the StatisticMonthComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'statistic-month',
  templateUrl: 'statistic-month.html'
})
export class StatisticMonthComponent {
  @Input('userId')
  private userId:string;
  @ViewChild('monthChart')
  private monthChart:ElementRef;
  @ViewChild('summary')
  private summary:ElementRef;

  private appointTimeStart;
  private appointTimeEnd;

  private months = ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];

  constructor( private getMsg:SendMessageProvider) {

  }

  getstatisticMonth(event){
    let year = new Date().getFullYear();
    switch (event){
      case '一月':
        this.appointTimeStart = new Date(year+'-1-01 00:00:00').getTime();
        this.appointTimeEnd = new Date(year+'-2-01 00:00:00').getTime();
        break;
      case '二月':
        this.appointTimeStart = new Date(year+'-2-01 00:00:00').getTime();
        this.appointTimeEnd = new Date(year+'-3-01 00:00:00').getTime();
        break;
      case '三月':
        this.appointTimeStart = new Date(year+'-3-01 00:00:00').getTime();
        this.appointTimeEnd = new Date(year+'-4-01 00:00:00').getTime();
        break;
      case '四月':
        this.appointTimeStart = new Date(year+'-4-01 00:00:00').getTime();
        this.appointTimeEnd = new Date(year+'-5-01 00:00:00').getTime();
        break;
      case '五月':
        this.appointTimeStart = new Date(year+'-5-01 00:00:00').getTime();
        this.appointTimeEnd = new Date(year+'-6-01 00:00:00').getTime();
        break;
      case '六月':
        this.appointTimeStart = new Date(year+'-6-01 00:00:00').getTime();
        this.appointTimeEnd = new Date(year+'-7-01 00:00:00').getTime();
        break;
      case '七月':
        this.appointTimeStart = new Date(year+'-7-01 00:00:00').getTime();
        this.appointTimeEnd = new Date(year+'-8-01 00:00:00').getTime();
        break;
      case '八月':
        this.appointTimeStart = new Date(year+'-8-01 00:00:00').getTime();
        this.appointTimeEnd = new Date(year+'-9-01 00:00:00').getTime();
        break;
      case '九月':
        this.appointTimeStart = new Date(year+'-9-01 00:00:00').getTime();
        this.appointTimeEnd = new Date(year+'-10-01 00:00:00').getTime();
        break;
      case '十月':
        this.appointTimeStart = new Date(year+'-10-01 00:00:00').getTime();
        this.appointTimeEnd = new Date(year+'-11-01 00:00:00').getTime();
        break;
      case '十一月':
        this.appointTimeStart = new Date(year+'-11-01 00:00:00').getTime();
        this.appointTimeEnd = new Date(year+'-12-01 00:00:00').getTime();
        break;
      case '十二月':
        this.appointTimeStart = new Date(year+'-12-01 00:00:00').getTime();
        this.appointTimeEnd = new Date((year+1)+'-1-01 00:00:00').getTime();
        break;
    }
    console.log("Start:"+this.appointTimeStart);
    console.log("End:"+this.appointTimeEnd);
    this.getMsg.sendMessageReturn('MonthStatisticServlet',{
      userId:this.userId,appointTimeStart:this.appointTimeStart,appointTimeEnd:this.appointTimeEnd
    }).map(res => res.json())
      .subscribe(data => {
        if(data.toString() != ''){
          this.monthChart.nativeElement.hidden = false;
          this.summary.nativeElement.hidden = true;
          this.monthChartsView(data);
        }else{
          this.monthChart.nativeElement.hidden = true;
          this.summary.nativeElement.innerText = '本月暂无学习记录';
          this.summary.nativeElement.hidden = false;
        }
      });
  }

  monthChartsView(data){
    let myChart = echarts.init(this.monthChart.nativeElement);
    let option =    {
      title : {
        text: '月选座统计记录',
      },
      tooltip : {
        trigger: 'axis',
        showDelay : 0,
        formatter : function (event) {
            return '日期：'+event[0].data[0]+'号<br/>'
          +'学习时间：'+event[0].data[1]+'小时';
        },
        axisPointer:{
          show: true,
          type : 'cross',
          lineStyle: {
            type : 'dashed',
            width : 1
          }
        }
      },
      toolbox: {
        show : true,
        feature : {
          mark : {show: true},
          dataZoom : {show: true},
          dataView : {show: true, readOnly: false},
          restore : {show: true},
          saveAsImage : {show: true}
        }
      },
      xAxis : [
        {
          type : 'value',
          scale:true,
          axisLabel : {
            formatter: '{value} 号'
          }
        }
      ],
      yAxis : [
        {
          type : 'value',
          scale:true,
          axisLabel : {
            formatter: '{value} h'
          }
        }
      ],
      series : [
        {
          name:'学习记录',
          type:'scatter',
          data: data,
          markPoint : {
            data : [
              {type : 'max', name: '最大值'},
              {type : 'min', name: '最小值'}
            ]
          },
          markLine : {
            data : [
              {type : 'average', name: '平均值'}
            ]
          }
        }
      ]
    };
    myChart.setOption(option);
  }
}
