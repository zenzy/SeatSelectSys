import { NgModule } from '@angular/core';
import { StatisticMonthComponent } from './statistic-month/statistic-month';
import {BrowserModule} from "@angular/platform-browser";
import {MyApp} from "../app/app.component";
import {IonicModule} from "ionic-angular";
import { StatisticWeeklyComponent } from './statistic-weekly/statistic-weekly';
@NgModule({
	declarations: [StatisticMonthComponent,
    StatisticWeeklyComponent],
	imports: [BrowserModule,IonicModule.forRoot(MyApp),],
	exports: [StatisticMonthComponent,
    StatisticWeeklyComponent]
})
export class ComponentsModule {

}
