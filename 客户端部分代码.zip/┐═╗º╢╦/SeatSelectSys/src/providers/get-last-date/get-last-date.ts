import { Injectable } from '@angular/core';

/*
  Generated class for the GetLastDateProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class GetLastDateProvider {

  constructor() {

  }

  //获得上周一时间
  getLastMondy(today):any{
    let lastMonday = new Date(today.getTime() - (today.getDay()+6)*86400000);
    let year = new Date(lastMonday).getFullYear();
    let month = new Date(lastMonday).getMonth()+1;
    let date = new Date(lastMonday).getDate();
    return year+'-'+month+'-'+date;
  }

  //获得上周日时间
  getLastSunday(today):any{
    let lastSunday = new Date(today.getTime() - today.getDay()*86400000);
    let year = new Date(lastSunday).getFullYear();
    let month = new Date(lastSunday).getMonth()+1;
    let date = new Date(lastSunday).getDate();
    return year+'-'+month+'-'+date;
  }

}
