
import { Injectable } from '@angular/core';
import {Http} from "@angular/http";

@Injectable()
export class SendMessageProvider {
  constructor(public http: Http) {

  }

  sendMessage(servletName,pramas):void{
    this.http.post('http://seatsys.s1.natapp.cc/servletDemo/'+servletName,pramas)
    .map(res => res.text())
    .subscribe(data =>   {
        console.log("发送数据到服务器，返回的结果是："+data);
      });
    }

  sendMessageReturn(servletName,pramas):any{
    return this.http.post('http://seatsys.s1.natapp.cc/servletDemo/'+servletName,pramas)
  }

  getMessage(servletName):any{
    return this.http.request('http://seatsys.s1.natapp.cc/servletDemo/'+servletName);
  }

}
