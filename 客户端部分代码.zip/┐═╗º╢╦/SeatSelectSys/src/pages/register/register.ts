import {Component, ElementRef, ViewChild} from '@angular/core';
import {IonicPage, NavController, ToastController,} from 'ionic-angular';
import {LoginPage} from "../login/login";
import {SendMessageProvider} from "../../providers/send-message/send-message";
import {ToastProvider} from "../../providers/toast/toast";



/**
 * Generated class for the RegisterPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-register',
  templateUrl: 'register.html',
})
export class RegisterPage {
  @ViewChild('promptMsg')
  private promptMsg:ElementRef;

  constructor(public navCtrl: NavController,
              private sendMsg:SendMessageProvider,
              private toast:ToastProvider
            ) {
  }

  ionViewDidLoad() {
    this.promptMsg.nativeElement.hidden = true;
  }

  register(userid, password){
    if(userid == '' || password == ''){
      this.toast.presentToast('请输入用户ID或密码','1000','top','toastClass');
    }else if(this.promptMsg.nativeElement.hidden == false){
      this.toast.presentToast('该用户ID已存在','1000','top','toastClass');
    }else{
      this.sendMsg.sendMessageReturn('RegisterServlet',{userId:userid,password:password})
        .map(res => res.text())
        .subscribe(data => {
          if(data == '注册成功'){
            //弹出注册成功提示框，并跳转到登录页面
            this.toast.presentToast('注册成功，即将返回登录页面','1000','top','toastClass');
            this.navCtrl.push(LoginPage,{
              userId:userid,
              password:password
            });
          }else{
            //弹出失败提示框
            this.toast.presentToast('服务器响应超时，请稍后重试','1000','top','toastClass');
          }
        });
    }

  }

  goLogin(){
    this.navCtrl.push(LoginPage);
  }

  onkey(params){
    let userid = params;
   this.sendMsg.sendMessageReturn('JudgeUserIdServlet',{userId:userid})
     .map(res => res.text())
     .subscribe(data => {
       if(data == '用户名存在'){
         this.promptMsg.nativeElement.hidden = false;
       }else if(data == '用户名不存在'){
         this.promptMsg.nativeElement.hidden = true;
       }
     });
  }


}
