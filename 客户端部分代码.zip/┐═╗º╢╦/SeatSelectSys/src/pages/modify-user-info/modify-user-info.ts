import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {HomePage} from "../home/home";

/**
 * Generated class for the ModifyUserInfoPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-modify-user-info',
  templateUrl: 'modify-user-info.html',
})
export class ModifyUserInfoPage {
  private sex;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ModifyUserInfoPage');
  }

  goHomePage(){
    this.navCtrl.setRoot(HomePage);
  }
}
