import {AfterViewInit, Component, ElementRef, OnChanges, OnInit, ViewChild} from '@angular/core';
import { NavController } from 'ionic-angular';
import {SeatSelectInfoPage} from "../seat-select-info/seat-select-info";
import {Http} from "@angular/http";
import "rxjs/add/operator/map";
import {SendMessageProvider} from "../../providers/send-message/send-message";
declare const echarts;

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage implements AfterViewInit,OnInit{


  @ViewChild('container')
  private container: ElementRef;
  public seatUseRate:number = 0;
  public myChart: any;
  private date;
  private floorSeatInfos  = [
    {
      floorNum:'一楼',
      maxCapacity:225,
      emptySeat:0
    },
    {
      floorNum:'二楼',
      maxCapacity:225,
      emptySeat:0
    },
    {
      floorNum:'三楼',
      maxCapacity:225,
      emptySeat:0
    },
    {
      floorNum:'四楼',
      maxCapacity:225,
      emptySeat:0
    },
    {
      floorNum:'五楼',
      maxCapacity:225,
      emptySeat:0
    },
  ];
  private userId;

  constructor(public navCtrl: NavController,public http: Http,public sendMsg:SendMessageProvider) {
    this.date = new Date();
    this.userId = window.localStorage.getItem('userId');
    console.log('homePage:'+this.userId);
    this.getSeatInfo();
  }
  ngAfterViewInit(): void {

  }

  ngOnInit(){

  }

  //跳转页面 并将数据传递到下一个页面
  goSeatSelectInfo(floorNum){
    this.navCtrl.push(SeatSelectInfoPage,{
      userId:'zzy',
      floorNum:floorNum,
    });
  };

  echartsView(data): void{
    this.myChart = echarts.init(this.container.nativeElement);
    let option = {
      series : [
        {
          name:'访问来源',
          type:'pie',
          radius : '60%',
          center: ['50%', '50%'],
          data:[
            {value:data, name:'已被使用'},
            {value:1-data, name:'未被使用'}
          ]
        }
      ]
    };
    this.myChart.setOption(option);
  }

  loadSeatInfo(event){
    setTimeout(() =>{
      this.getSeatInfo();
      event.complete();
    },1000)


  }

  getSeatInfo(){
    this.sendMsg.getMessage('GetSeatInfoServlet')
      .map(res => res.json())
      .subscribe(data => {
        console.log(data);
        if(data.toString() == ''){
          this.seatUseRate = 0;
          for(let i=0;i<this.floorSeatInfos.length;i++){
            this.floorSeatInfos[0].emptySeat = 225;
            this.floorSeatInfos[1].emptySeat = 225;
            this.floorSeatInfos[2].emptySeat = 225;
            this.floorSeatInfos[3].emptySeat = 225;
            this.floorSeatInfos[4].emptySeat = 225;
          }
        }else{
          let sum = 0;
          this.floorSeatInfos[0].emptySeat = 255;
          this.floorSeatInfos[1].emptySeat = 255;
          this.floorSeatInfos[2].emptySeat = 255;
          this.floorSeatInfos[3].emptySeat = 255;
          this.floorSeatInfos[4].emptySeat = 255;

          for(let i=0;i<data.length;i++){
            switch(data[i].floorNum){
              case '一楼':this.floorSeatInfos[0].emptySeat = (255-data[i].usedSeating);break;
              case '二楼':this.floorSeatInfos[1].emptySeat = (255-data[i].usedSeating);break;
              case '三楼':this.floorSeatInfos[2].emptySeat = (255-data[i].usedSeating);break;
              case '四楼':this.floorSeatInfos[3].emptySeat = (255-data[i].usedSeating);break;
              case '五楼':this.floorSeatInfos[4].emptySeat = (255-data[i].usedSeating);break;
            }
            sum = sum+data[i].usedSeating;
          }
          this.seatUseRate = sum/1125;
          this.echartsView(this.seatUseRate);
        }
      });
  }


}


