import {Component} from '@angular/core';
import {IonicPage, NavController, NavParams} from 'ionic-angular';
import {TabsPage} from "../tabs/tabs";
import {RegisterPage} from "../register/register";
import {SendMessageProvider} from "../../providers/send-message/send-message";
import {ToastProvider} from "../../providers/toast/toast";

/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  userData:any = {
    userid:'',
    password:''
  };

  constructor(public navCtrl: NavController,
              public nav:NavParams,
              public sendMsg:SendMessageProvider,
              public toast:ToastProvider) {
    this.userData.userid = this.nav.get("userId");
    this.userData.password = this.nav.get("password");
  }

  ionViewDidLoad() {

}

  logIn(userid,password){
    if(userid == '' || password == ''){
      this.toast.presentToast('请输入用户名或密码','1000','top','toastClass');
    }else{
      console.log(userid+'...'+password);
      this.sendMsg.sendMessageReturn('LoginServlet',{
        userId:userid,
        password:password
      }).map(res => res.text())
        .subscribe(data => {
          console.log('data:'+data);
          if(data == '登录失败'){
            this.toast.presentToast('用户名或密码错误，请重新输入','1000','top','toastClass');
          }else if(data == '登录成功'){
            window.localStorage.setItem('userId',userid);
            this.navCtrl.setRoot(TabsPage);
          }else{
            this.toast.presentToast('出现未知错误，请稍后重试','1000','top','toastClass');
          }
        });
    }
  }

  //跳转到注册页面
  goRegister(){
    this.navCtrl.push(RegisterPage);
  }
}
