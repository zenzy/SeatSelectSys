import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SeatSelectInfoPage } from './seat-select-info';

@NgModule({
  declarations: [
    SeatSelectInfoPage,
  ],
  imports: [
    IonicPageModule.forChild(SeatSelectInfoPage),
  ],
})
export class SeatSelectInfoPageModule {}
