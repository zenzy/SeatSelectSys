///<reference path="../../assets/js/jquery.d.ts"/>
import {Component, OnInit} from '@angular/core';
import {IonicPage, NavController, ToastController, NavParams} from 'ionic-angular';
import {SendMessageProvider} from "../../providers/send-message/send-message";
/**
 * Generated class for the SeatSelectInfoPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-seat-select-info',
  templateUrl: 'seat-select-info.html',
})
export class SeatSelectInfoPage implements OnInit{
  private seatNum:number;
  public userId:string;
  public floorNum:string;
  private seatSelectedInfo = {
    userId:'',
    floorNum:'',
    seatId:'',
    seatNum:'',
    appointmentTime:0,
    lastArriveTime:0
  };
  public usedSeatId:string[];


  constructor(private navPrams: NavParams,
    public navCtrl: NavController,
    private toastCtrl:ToastController,
    private converMsg:SendMessageProvider,
    )
 {
    this.userId = this.navPrams.get('userId');
    this.floorNum = this.navPrams.get('floorNum');
}
  ngOnInit(): void {
    this.converMsg.sendMessageReturn('JudgeUserSeatedServlet',{userId:this.userId})
      .map(res => res.text())
      .subscribe(data => {
        if(data !== "404"){
          let str = data.split(',');
          let userSeatedFloorNum = str[0];
          let userSeatedSeatNum = str[1];
          $('#cannotChooseContent').text('你已选择了'+userSeatedFloorNum+'第'+userSeatedSeatNum+'号座位,如需选座请先前往选座结果页面结束当前选座');
        }
      });
    this.seatSelected();
  }

  seatSelected(){
    let firstSeatLabel = 1;
    let $cart = $('#selected-seats');//座位区
    let sc = $('#seat-map').seatCharts({
      map: [//座位图
        '_______________aaaaa',
        '_______________aaaaa',
        '_______________aaaaa',
        '_______________aaaaa',
        '_______________aaaaa',
        'aaaaaaaaaaaaaaaaaaaa',
        'aaaaaaaaaaaaaaaaaaaa',
        'aaaaaaaaaaaaaaaaaaaa',
        'aaaaaaaaaaaaaaaaaaaa',
        'aaaaaaaaaaaaaaaaaaaa',
        'aaaaaaaaaaaaaaaaaaaa',
        'aaaaaaaaaaaaaaaaaaaa',
        'aaaaaaaaaaaaaaaaaaaa',
        'aaaaaaaaaaaaaaaaaaaa',
        'aaaaaaaaaaaaaaaaaaaa',
      ],
      naming: {
        top:false,
        getLabel : function(character,row,column){
          return firstSeatLabel++;
        }
      },
      legend:{//定义图例
        node:$('#legend'),
        items : [
          ['a','available','可选座'],
          ['a','unavailable','已被选']
        ]
      },
      click: function(){//点击事件
        if($('#cannotChooseContent').text() == '' && this.settings.status == "available"){
          this.seatNum = this.settings.label;
          $("#dialogContent").text("你确定选择"+this.seatNum+"号座位吗？");
          $(".sure").data("seatId",this.settings.id);
          $("#dialogContent,#ResultDialog").fadeIn(500);
        } else if(this.settings.status == "unavailable"){
            $("#cannotChoose").fadeIn(200);
            return 'unavailable'
        } else{
            $("#cannotChoose").fadeIn(200);
            //this.settings.status = 'unavailable';
        }
      }
      });
    //获取已经被选取的座位信息，并显示在页面上
    this.converMsg.sendMessageReturn('GetUsedSeatId',{floorNum:this.floorNum})
      .map(res => res.text())
      .subscribe(data => {
        this.usedSeatId = data.split(',');
        this.usedSeatId.length--;
        sc.get(this.usedSeatId).status('unavailable');
      });
  }

  sure(){
    /*
    1、将座位信息提交到数据库
    2、改变该座位的颜色为被选中的颜色
    3、提交选座信息到选座结果页面
    4、关闭弹窗
    */
    let sureId = $(".sure").data("seatId");
    $("#"+sureId).css("background-color","red");
    $("#dialogContent,#ResultDialog").fadeOut(200);
    this.toastMsg("选座成功，请您在20分钟内到达该座位");

    //发送结果到数据库
    this.seatSelectedInfo.userId = this.userId;
    this.seatSelectedInfo.floorNum = this.floorNum;
    this.seatSelectedInfo.seatId = sureId;
    this.seatSelectedInfo.seatNum = $("#"+sureId).text();
    let date = new Date();
    this.seatSelectedInfo.appointmentTime = date.getTime();
    this.converMsg.sendMessage('AddSeatInfoServlet',this.seatSelectedInfo);
  }

  cancleDialog(){
    $("#dialogContent,#ResultDialog").fadeOut(200);
  }

  cannotChooseSure(){
    $("#cannotChoose").fadeOut(200);
  }

  //toast提示框
  toastMsg(msg){
    let toast = this.toastCtrl.create({
      message: msg,
      duration: 2000,
      position: 'middle'
    });
    toast.present();
  }
}
