import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SeatResultPage } from './seat-result';

@NgModule({
  declarations: [
    SeatResultPage,
  ],
  imports: [
    IonicPageModule.forChild(SeatResultPage),
  ],
})
export class SeatResultPageModule {}
