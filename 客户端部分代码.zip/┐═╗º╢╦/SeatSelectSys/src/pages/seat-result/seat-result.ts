import {Component, ElementRef, ViewChild} from '@angular/core';
import {Events, IonicPage, ItemSliding, NavController, NavParams, reorderArray} from 'ionic-angular';
import {SendMessageProvider} from "../../providers/send-message/send-message";

/**
 * Generated class for the SeatResultPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-seat-result',
  templateUrl: 'seat-result.html',
})
export class SeatResultPage {
  public userId = '';
  private userEndSeatInfos:any;
  private userOrderSeatInfos:any;

  private cancelOrderBtn = false;
  private arriveBtn = false;
  private endStudyBtn = false;
  private arriveDiv = true;
  private endTimeDiv = true;

  constructor(public getMsg:SendMessageProvider) {
    this.userId = window.localStorage.getItem('userId');
    this.getEndSeatedInfo();
    this.getOrderSeatedInfo();
  }



  delete(appointmentTime){
  this.getMsg.sendMessage('DelUserSeatHistoryServlet',{userId:this.userId,appointTime:appointmentTime});
  this.getEndSeatedInfo();
}

  //下拉刷新加载获取用户的座位信息
  loadSeatedResult(event){
    setTimeout(() =>{
      this.getOrderSeatedInfo();
      this.getEndSeatedInfo();
      event.complete();
      },1000)
  }

  //取消预约
  cancelOrder(appointmentTime){
    this.getMsg.sendMessage('CancelOrderServlet',{userId:this.userId,appointTime:appointmentTime});
    setTimeout(() =>{
      this.getOrderSeatedInfo();
      this.getEndSeatedInfo();
    },100)
  }

  //确认到达
  confirmArrive(appointmentTime){
    let time = new Date().getTime();
    this.getMsg.sendMessage('SendArriveTimeServlet',{userId:this.userId,appointTime:appointmentTime,arriveTime:time});
    this.getOrderSeatedInfo();
  }

  //结束学习
  endStudy(appointmentTime,arriveTime){
    let endtime = new Date().getTime();
    let studytime = endtime-arriveTime;
    let date = new Date(appointmentTime);
    let appointmentDate = date.getFullYear()+"-0"+(date.getMonth()+1)+"-"+date.getDate();
    this.getMsg.sendMessage('SendEndTimeServlet',{userId:this.userId,appointTime:appointmentTime,endTime:endtime,studyTime:studytime,appointDate:appointmentDate});
    this.getEndSeatedInfo();
    this.getOrderSeatedInfo();

  }

  //从服务器获取用户结束选座的座位信息
  getEndSeatedInfo(){
    this.getMsg.sendMessageReturn("GetUserSeatEndResultServlet",{userId:this.userId})
      .map(res => res.json())
      .subscribe(data => {
        this.userEndSeatInfos = data;
      })
  }
  //从服务器获取用户未结束选座的座位信息
  getOrderSeatedInfo(){
    this.getMsg.sendMessageReturn("GetUserSeatOrderResultServlet",{userId:this.userId})
      .map(res => res.json())
      .subscribe(data => {
        this.userOrderSeatInfos = data;
        if(this.userOrderSeatInfos.toString() != ''){
          if(this.userOrderSeatInfos[0].arriveTime == 0 && this.userOrderSeatInfos[0].endTime == 0){
            this.cancelOrderBtn = true;
            this.arriveBtn = true;
            this.endStudyBtn = false;
            this.arriveDiv = false;
            this.endTimeDiv = false;
          }else if(this.userOrderSeatInfos[0].arriveTime != 0 && this.userOrderSeatInfos[0].endTime == 0){
            this.cancelOrderBtn = false;
            this.arriveBtn = false;
            this.endStudyBtn = true;
            this.arriveDiv = true;
            this.endTimeDiv = false;
          }else if(this.userOrderSeatInfos[0].arriveTime != 0 && this.userOrderSeatInfos[0].endTime != 0){
            this.cancelOrderBtn = false;
            this.arriveBtn = false;
            this.endStudyBtn = false;
            this.arriveDiv = true;
            this.endTimeDiv = true;
          }else{
            this.cancelOrderBtn = false;
            this.arriveBtn = false;
            this.endStudyBtn = false;
            this.arriveDiv = true;
            this.endTimeDiv = true;
          }
        }
      })
  }

}
