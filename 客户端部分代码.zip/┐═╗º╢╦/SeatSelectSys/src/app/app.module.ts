import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import {TabsPage} from "../pages/tabs/tabs";
import {SeatResultPage} from "../pages/seat-result/seat-result";
import {StatisticsPage} from "../pages/statistics/statistics";
import {SeatSelectInfoPage} from "../pages/seat-select-info/seat-select-info";
import {HttpModule} from "@angular/http";
import { SendMessageProvider } from '../providers/send-message/send-message';
import { GetLastDateProvider } from '../providers/get-last-date/get-last-date';
import {ComponentsModule} from "../components/components.module";
import {LoginPage} from "../pages/login/login";
import {RegisterPage} from "../pages/register/register";
import { ToastProvider } from '../providers/toast/toast';
import {ModifyUserInfoPage} from "../pages/modify-user-info/modify-user-info";
import {FeedbackPage} from "../pages/feedback/feedback";


@NgModule({
  declarations: [
    MyApp,
    HomePage,
    TabsPage,
    SeatResultPage,
    StatisticsPage,
    SeatSelectInfoPage,
    LoginPage,
    RegisterPage,
    ModifyUserInfoPage,
    FeedbackPage
  ],
  imports: [
    BrowserModule,
    HttpModule,
    IonicModule.forRoot(MyApp),
    ComponentsModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    TabsPage,
    SeatResultPage,
    StatisticsPage,
    SeatSelectInfoPage,
    LoginPage,
    RegisterPage,
    ModifyUserInfoPage,
    FeedbackPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    SendMessageProvider,
    GetLastDateProvider,
    ToastProvider
  ]
})
export class AppModule {}
