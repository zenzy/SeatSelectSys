import {Component, ViewChild} from '@angular/core';
import {MenuController, NavController, Platform} from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import {LoginPage} from "../pages/login/login";
import {TabsPage} from "../pages/tabs/tabs";
import {ModifyUserInfoPage} from "../pages/modify-user-info/modify-user-info";
import {FeedbackPage} from "../pages/feedback/feedback";
@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild('myNav') nav:NavController;
  rootPage:any;
  menuLists = ['修改资料','清除缓存','问题反馈'];

  constructor(
    public menuCtrl: MenuController,
    platform: Platform,
    statusBar: StatusBar,
    splashScreen: SplashScreen
              ) {

    if(window.localStorage.getItem('userId')){
      this.rootPage = TabsPage;
    }else{
      this.rootPage = LoginPage;
    }

    platform.ready().then(() => {
      statusBar.styleDefault();
      splashScreen.hide();
    });
  }

  menuListClick(params){
    if(params == '修改资料'){
      this.menuCtrl.close();
      this.nav.setRoot(ModifyUserInfoPage);
    }else if(params == '清除缓存'){
      console.log(params);
    }else if(params == '问题反馈'){
      this.menuCtrl.close();
      this.nav.setRoot(FeedbackPage);
    }


  }
  exitLogin(){
    window.localStorage.removeItem('userId');
    this.menuCtrl.close();
    this.nav.setRoot(LoginPage);
  }
}

